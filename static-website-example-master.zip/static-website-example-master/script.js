









// let p = document.getElementsByTagName('p')
// let b = document.getElementsByTagName('p')

// if (window.innerWidth < 576) {

//     for (let a = 0; a <= p?.length; a++) {
//         if (p[a]?.innerHTML?.includes('img')) {
//         }
//         else {
//             if (p[a]?.innerText.length <= 99) {

//             }
//             else {
//                 let sum = ''
//                 let sum2 = ''
//                 for (let i = 0; i < p[a]?.innerText.length; i++) {

//                     if (i <= 100) {

//                         sum += p[a].innerText[i];
//                     }
//                     else {
//                         sum2 += p[a].innerText[i]
//                     }
//                 }


//                 let textHideShow = document.getElementsByClassName('text-hide-show-p');
//                 let id = 'c';

//                 for (let i = 0; i < textHideShow.length; i++) {

//                     id = i + 100
//                     id = String.fromCharCode(id)

//                     textHideShow[i].addEventListener('click', () => {

//                     })
//                 }

//                 p[a].innerHTML = sum + `<span  id= '${id}'  class="extra-para" >${sum2}</span>  <a style="color:red;" class="text-hide-show-p ${id}"  >Read More</a> `;
//                 document.querySelector(`.${id}`).addEventListener('click', () => {
//                     let className = id
//                     let idclass = document.querySelector(`#${className}`)

//                     if (idclass.style.display != "block") {
//                         idclass.style.display = "block"
//                         document.querySelector(`.${id}`).innerText = "Read Less"
//                     }
//                     else {
//                         idclass.style.display = "none"
//                         document.querySelector(`.${id}`).innerText = "Read More"
//                     }
//                 })
//             }

//         }
//     }

// }










// let paragraphs = document.getElementsByTagName('p');

// if (window.innerWidth < 576) {
//     for (let i = 0; i < paragraphs?.length; i++) {
//         let currentParagraph = paragraphs[i];

//         if (!currentParagraph?.innerHTML?.includes('img')) {
//             if (currentParagraph?.innerText.length > 99) {
//                 let summary = currentParagraph.innerText.slice(0, 100);
//                 let remainingText = currentParagraph.innerText.slice(100);

//                 let id = String.fromCharCode(i + 100);
//                 currentParagraph.innerHTML = `${summary}<span id='${id}' class="extra-para">${remainingText}</span><a style="color:red;" class="text-hide-show-p ${id}">Read More</a>`;

//                 document.querySelector(`.${id}`).addEventListener('click', () => {
//                     let idClass = document.querySelector(`#${id}`);

//                     if (idClass.style.display !== 'block') {
//                         idClass.style.display = 'block';
//                         document.querySelector(`.${id}`).innerText = 'Read Less';
//                     } else {
//                         idClass.style.display = 'none';
//                         document.querySelector(`.${id}`).innerText = 'Read More';
//                     }
//                 });
//             }
//         }
//     }
// }



const paragraphs = document.getElementsByTagName('p');

if (window.innerWidth < 576) {
    for (let i = 0; i < paragraphs?.length; i++) {
        const currentParagraph = paragraphs[i];
        const { innerHTML, innerText } = currentParagraph;

        if (!innerHTML?.includes('img') && innerText.length > 99) {
            const [summary, remainingText] = [innerText.slice(0, 100), innerText.slice(100)];
            const id = String.fromCharCode(i + 100);

            currentParagraph.innerHTML = `${summary}<span id='${id}' class="extra-para">${remainingText}</span><a style="color:red;" class="text-hide-show-p ${id}">Read More</a>`;

            document.querySelector(`.${id}`).addEventListener('click', () => {
                const idClass = document.querySelector(`#${id}`);
                idClass.style.display = (idClass.style.display !== 'inline') ? 'inline' : 'none';
                document.querySelector(`.${id}`).innerText = (idClass.style.display !== 'inline') ? 'Read More' : 'Read Less';
            });
        }
    }
}



